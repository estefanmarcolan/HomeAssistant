Como desenvolver notificação unificadas dos status de bateria

Card Battery: https://github.com/maxwroc/battery-state-card (Instalação via HACS)

Projeto para importação (Blueprint): Clique para importar

Vídeo explicativo: 

https://www.youtube.com/watch?si=3WQh7MWvurOQ3KsZ&embeds_referring_euri=http%3A%2F%2Fwww.patte.com.br%2F&source_ve_path=MTY0NTA2&feature=emb_share&v=46-AI6GV0CE


